from math import *
import numpy as np

# Script to plot workspace of arm